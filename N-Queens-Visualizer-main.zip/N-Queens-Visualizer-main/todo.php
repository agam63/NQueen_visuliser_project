<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
  <h1>To-Do List</h1>
  <input type="text" id="task" placeholder="Add a task">
  <button id="add">Add</button>
  <ul id="tasks"></ul>
</body>
<script src="script.js"></script>
</html>
